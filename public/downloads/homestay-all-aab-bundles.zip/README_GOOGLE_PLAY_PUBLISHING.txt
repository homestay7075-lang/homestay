﻿================================================================================
HOME STAY - GOOGLE PLAY STORE (.AAB) PUBLISHING INSTRUCTIONS
================================================================================

This package contains signed release-ready Android App Bundles (.aab) for Home Stay:

1. homestay-student-release.aab (com.homestay.resident)
   -> Targeted at hostel students & residents. Opens directly to /app.

2. homestay-owner-release.aab (com.homestay.owner)
   -> Targeted at hostel owners/administrators. Opens directly to /dashboard.

3. homestay-staff-release.aab (com.homestay.staff)
   -> Targeted at wardens, accountants, and staff members.

================================================================================
HOW TO UPLOAD TO GOOGLE PLAY CONSOLE:
================================================================================
1. Go to https://play.google.com/console and log in to your Google Play Developer account.
2. Click "Create App".
   - Name: Home Stay Resident (or Home Stay Owner Hub)
   - Default language: English (United States or India)
   - App or game: App
   - Free or paid: Free
3. In the left sidebar, navigate to "Release" -> "Production" (or "Internal testing").
4. Click "Create new release".
5. In the "App bundles" section, click "Upload" and select your .aab file:
   - For Students: homestay-student-release.aab
   - For Owners: homestay-owner-release.aab
   - For Staff: homestay-staff-release.aab
6. Add release notes (e.g., "Initial official release v1.0.0 with resident pass, dues, and messaging").
7. Click "Next" -> "Save and publish".

================================================================================
ASSETLINKS VERIFICATION (Already Configured on Server):
================================================================================
Your server already serves /.well-known/assetlinks.json to verify ownership
and eliminate the browser address bar inside the native Android application.

Need help or custom signing? Contact Home Stay Support.
